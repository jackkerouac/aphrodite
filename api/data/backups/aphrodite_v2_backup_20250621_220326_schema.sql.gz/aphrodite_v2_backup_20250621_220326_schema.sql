-- Aphrodite v2 Database Backup (SQLAlchemy method)
-- Created: 2025-06-21T22:03:26.809511
-- Database: aphrodite

-- Table: badge_configs
DROP TABLE IF EXISTS badge_configs CASCADE;
CREATE TABLE badge_configs (  id character varying NOT NULL,
  type character varying NOT NULL,
  enabled boolean NOT NULL,
  settings json,
  created_at timestamp without time zone NOT NULL,
  updated_at timestamp without time zone NOT NULL
);

-- No data in table badge_configs

-- Table: batch_jobs
DROP TABLE IF EXISTS batch_jobs CASCADE;
CREATE TABLE batch_jobs (  id character varying NOT NULL,
  user_id character varying NOT NULL,
  name character varying NOT NULL,
  source character varying NOT NULL,
  total_posters integer NOT NULL,
  completed_posters integer NOT NULL,
  failed_posters integer NOT NULL,
  status character varying NOT NULL,
  priority integer NOT NULL,
  badge_types json NOT NULL,
  selected_poster_ids json NOT NULL,
  created_at timestamp without time zone NOT NULL,
  started_at timestamp without time zone,
  completed_at timestamp without time zone,
  estimated_completion timestamp without time zone,
  error_summary text
);

-- No data in table batch_jobs

-- Table: media_items
DROP TABLE IF EXISTS media_items CASCADE;
CREATE TABLE media_items (  id character varying NOT NULL,
  title character varying NOT NULL,
  media_type character varying NOT NULL,
  year integer,
  poster_url text,
  jellyfin_id character varying,
  tmdb_id integer,
  imdb_id character varying,
  overview text,
  genres json,
  runtime integer,
  community_rating character varying,
  official_rating character varying,
  premiere_date character varying,
  series_name character varying,
  season_number integer,
  episode_number integer,
  additional_metadata json,
  created_at timestamp without time zone NOT NULL,
  updated_at timestamp without time zone NOT NULL
);

-- No data in table media_items

-- Table: poster_processing_status
DROP TABLE IF EXISTS poster_processing_status CASCADE;
CREATE TABLE poster_processing_status (  id character varying NOT NULL,
  batch_job_id character varying NOT NULL,
  poster_id character varying NOT NULL,
  status character varying NOT NULL,
  started_at timestamp without time zone,
  completed_at timestamp without time zone,
  output_path character varying,
  error_message text,
  retry_count integer NOT NULL
);

-- No data in table poster_processing_status

-- Table: processing_jobs
DROP TABLE IF EXISTS processing_jobs CASCADE;
CREATE TABLE processing_jobs (  id character varying NOT NULL,
  media_id character varying NOT NULL,
  status character varying NOT NULL,
  progress double precision NOT NULL,
  job_type character varying NOT NULL,
  parameters json,
  created_at timestamp without time zone NOT NULL,
  updated_at timestamp without time zone NOT NULL,
  started_at timestamp without time zone,
  completed_at timestamp without time zone,
  result json,
  error_message text,
  retry_count integer NOT NULL
);

-- No data in table processing_jobs

-- Table: schedule_executions
DROP TABLE IF EXISTS schedule_executions CASCADE;
CREATE TABLE schedule_executions (  id uuid NOT NULL,
  schedule_id uuid NOT NULL,
  status character varying NOT NULL,
  started_at timestamp with time zone,
  completed_at timestamp with time zone,
  error_message text,
  items_processed character varying,
  created_at timestamp with time zone DEFAULT now()
);

-- No data in table schedule_executions

-- Table: schedules
DROP TABLE IF EXISTS schedules CASCADE;
CREATE TABLE schedules (  id uuid NOT NULL,
  name character varying NOT NULL,
  timezone character varying NOT NULL,
  cron_expression character varying NOT NULL,
  badge_types ARRAY NOT NULL,
  reprocess_all boolean NOT NULL,
  enabled boolean NOT NULL,
  target_libraries ARRAY NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- No data in table schedules

-- Table: system_config
DROP TABLE IF EXISTS system_config CASCADE;
CREATE TABLE system_config (  id character varying NOT NULL,
  key character varying NOT NULL,
  value json,
  created_at timestamp without time zone NOT NULL,
  updated_at timestamp without time zone NOT NULL
);

-- Data for table system_config (2 rows)
INSERT INTO system_config (id, key, value, created_at, updated_at) VALUES ('e12f809a-1d1c-4fbc-8bef-e4dc6d97aa43', 'system', '{'jellyfin_url': 'https://jellyfin.okaymedia.ca', 'jellyfin_api_key': '16dc3768e2754ff8b445a4728323a5e8', 'jellyfin_user_id': '484068279393441885f9272eba479ccd'}', '2025-06-22 02:00:49.613823', '2025-06-22 02:00:51.822121');
INSERT INTO system_config (id, key, value, created_at, updated_at) VALUES ('088902d2-89f9-4735-9003-7aeb8c27a829', 'settings.yaml', '{'api_keys': {'Jellyfin': [{'url': 'https://jellyfin.okaymedia.ca', 'api_key': '16dc3768e2754ff8b445a4728323a5e8', 'user_id': '484068279393441885f9272eba479ccd'}], 'OMDB': [{'api_key': '', 'cache_expiration': 60}], 'TMDB': [{'api_key': '', 'cache_expiration': 60, 'language': 'en', 'region': None}], 'aniDB': [{'username': ''}, {'password': '', 'version': 1, 'client_name': '', 'language': 'en', 'cache_expiration': 60}], 'MDBList': [{'api_key': '', 'cache_expiration': 60}]}}', '2025-06-22 02:00:49.660282', '2025-06-22 02:00:51.869001');
